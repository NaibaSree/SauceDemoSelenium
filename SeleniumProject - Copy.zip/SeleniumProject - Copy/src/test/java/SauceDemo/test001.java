package SauceDemo;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import Maven.SeleniumProject.CheckOutOverview;
import Maven.SeleniumProject.checkOut;
import Maven.SeleniumProject.comman_methods;
import Maven.SeleniumProject.extendReport;
import Maven.SeleniumProject.login;
import Maven.SeleniumProject.product;
import Maven.SeleniumProject.verify;
import Maven.SeleniumProject.yourCart;

import java.io.IOException;

import org.openqa.selenium.*;


public class test001 extends comman_methods {

	login i=new login();
	product p=new product();
	yourCart y=new yourCart();
	checkOut c=new checkOut();
	verify v=new verify();
	CheckOutOverview coo=new CheckOutOverview();
	
	static ExtentReports extent;
    static ExtentTest test;
	@BeforeClass
	public void launch() {
		extent = extendReport.getReportInstance("test001");
		test = extent.createTest("test001 Started, Opened Browser");
		launch_firefox("https://www.saucedemo.com/");
		test.log(Status.INFO, "Browser Opened");
	}
	@Test(priority=0)
	public void UrlAssertion() {
		test = extent.createTest("UrlAssertion Started");
		String title="Swag Labs";
		String url="https://www.saucedemo.com/";
		Assert.assertEquals(title,i.url());
		Assert.assertEquals(url, dr.getCurrentUrl());
		test.log(Status.INFO, "SauceDemo login page Opened");
		test.pass("UrlAssertion passed");	
	}

	@Test(priority=1)
	public void login_successful() throws IOException, InterruptedException {
		test = extent.createTest("Entering username and password");
		String eo="Products";
		Assert.assertEquals(eo, i.Sulogin());
		test.log(Status.INFO, "Entered username and password");
		test.pass("Logged in passed");
	}

	@Test(priority=2)
	public void Z_A()  {
		test = extent.createTest("Ordering the product as Z-A");
		Assert.assertEquals(true,p.Z_A());
		test.log(Status.INFO, "Product are arranged in the Z-A order");
		test.pass("Z-A passed");
	}
	@Test(priority=3)
	public void addtocart()  {
		test = extent.createTest("Add to cart");
		String eo="Test.allTheThings() T-Shirt (Red)";
		Assert.assertEquals(eo, p.addItem());
		test.log(Status.INFO, "Product on cart");
		test.pass("addtocart passed");

	}
	@Test(priority=4)
	public void YourCart()  {
		test = extent.createTest("On the YourCart page");
		y.ycart();
		test.log(Status.INFO, "Products on Yourcart Page");
		test.pass("YourCart passed");
	}

	@Test(priority=5)
	public void CheckOut()  {
		test = extent.createTest("On the CheckOut page");
		c.Cout();
		test.log(Status.INFO, "Products on CheckOut Page");
		test.pass("CheckOut passed");
	}
	
	@Test(priority=6)
	public void CheckOutOverview()  {
		test = extent.createTest("On the CheckOutOverview page");
		coo.overView();
		test.log(Status.INFO, "Products on CheckOutOverview Page");
		test.pass("CheckOutOverview passed");

	}
	@Test(priority=7)
	public void Verify()  {
		test = extent.createTest("On the after Ordered  page");
		String eo="Thank you for your order!";
		String ao=v.veri();
		Assert.assertEquals(eo, ao);
		test.log(Status.INFO, "Successfully ordered");
		test.pass("verify passed");
	}

	@AfterClass
	public void quit() {
		extent.flush();
		dr.quit();
	}
}
