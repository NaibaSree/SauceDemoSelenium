package SauceDemo;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import Maven.SeleniumProject.Anchor_Tag;
import Maven.SeleniumProject.comman_methods;
import Maven.SeleniumProject.extendReport;
import Maven.SeleniumProject.loginTest2;

public class test002 extends comman_methods {
	Anchor_Tag a=new Anchor_Tag();
	loginTest2 l=new loginTest2();
	static ExtentReports extent;
    static ExtentTest test;
	@BeforeTest
	public void launch() {
		extent = extendReport.getReportInstance("test002");
		test = extent.createTest("test002 Started, Opened Browser");
		launch_firefox("https://www.saucedemo.com/");
		test.log(Status.INFO, "Browser Opened");
	}
	@Test
	public void ATag() {
		test = extent.createTest("test002 Started, Opened Browser");
		l.d_login();
		a.get_Tag();
		test.log(Status.INFO, "After login diplaying value present on every anchor tag ");
		test.pass("ATag passed");
	}

	@AfterClass
	public void quit() {
		dr.quit();
		extent.flush();
	}
}
