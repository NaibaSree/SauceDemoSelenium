package Maven.SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class verify extends comman_methods{
	public String veri() {
		WebElement we=dr.findElement(By.className("complete-header"));
		String ao=we.getText();
		return ao;
	}
}
