package Maven.SeleniumProject;

import org.openqa.selenium.By;

public class checkOut extends comman_methods{
	public void Cout() {
		dr.findElement(By.id("first-name")).sendKeys("Naiba");
		dr.findElement(By.id("last-name")).sendKeys("P");
		dr.findElement(By.id("postal-code")).sendKeys("123456");
		dr.findElement(By.id("continue")).click();
	}
}
