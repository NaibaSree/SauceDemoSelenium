package Maven.SeleniumProject;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class product extends comman_methods{
	public boolean Z_A() {
		WebElement dropdown=dr.findElement(By.className("product_sort_container"));
		Select s=new Select(dropdown);
		s.selectByContainsVisibleText("Name (Z to A)");
		List<String> EL=new ArrayList<>();
		List<String> AL=new ArrayList<>();
		EL.add("Test.allTheThings() T-Shirt (Red)");
		EL.add("Sauce Labs Onesie");
		EL.add("Sauce Labs Fleece Jacket");
		EL.add("Sauce Labs Bolt T-Shirt");
		EL.add("Sauce Labs Bike Light");
		EL.add("Sauce Labs Backpack");
		String wb1=dr.findElement(By.xpath("//div[@class=\"inventory_list\"]/div[1]/div[2]/div[1]/a/div")).getText();
		String wb2=dr.findElement(By.xpath("//div[@class=\"inventory_list\"]/div[2]/div[2]/div[1]/a/div")).getText();
		String wb3=dr.findElement(By.xpath("//div[@class=\"inventory_list\"]/div[3]/div[2]/div[1]/a/div")).getText();
		String wb4=dr.findElement(By.xpath("//div[@class=\"inventory_list\"]/div[4]/div[2]/div[1]/a/div")).getText();
		String wb5=dr.findElement(By.xpath("//div[@class=\"inventory_list\"]/div[5]/div[2]/div[1]/a/div")).getText();
		String wb6=dr.findElement(By.xpath("//div[@class=\"inventory_list\"]/div[6]/div[2]/div[1]/a/div")).getText();
		AL.add(wb1);
		AL.add(wb2);
		AL.add(wb3);
		AL.add(wb4);
		AL.add(wb5);
		AL.add(wb6);
		if(EL.equals(AL))
			return true;
		return false;
	}
	
	public String addItem() {
		dr.findElement(By.xpath("//div[@class=\"inventory_list\"]/div[1]/div[2]/div[2]/button")).click();
		dr.findElement(By.className("shopping_cart_link")).click();
		String wb=dr.findElement(By.xpath("//div[@class=\"inventory_item_name\"]")).getText();
		return wb;
		
		
	}


}
