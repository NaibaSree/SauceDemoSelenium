package Maven.SeleniumProject;

import org.openqa.selenium.By;

public class CheckOutOverview extends comman_methods{
	public void overView() {
		dr.findElement(By.id("finish")).click();
	}

}
