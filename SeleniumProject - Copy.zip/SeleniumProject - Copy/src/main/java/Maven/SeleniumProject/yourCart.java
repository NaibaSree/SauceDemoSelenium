package Maven.SeleniumProject;

import org.openqa.selenium.By;

public class yourCart extends comman_methods{
	public void ycart() {
		dr.findElement(By.id("checkout")).click();;
	}

}
