package Maven.SeleniumProject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Anchor_Tag extends comman_methods{
	public void get_Tag() {
		List<WebElement> list=dr.findElements(By.xpath("//a"));
		System.out.println("Anchor tags on this page");
		for(WebElement i:list) {
			System.out.println(i.getText());
		}
	}
}
