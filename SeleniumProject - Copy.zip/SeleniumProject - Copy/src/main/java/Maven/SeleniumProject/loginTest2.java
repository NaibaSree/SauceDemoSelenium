package Maven.SeleniumProject;

import org.openqa.selenium.By;

public class loginTest2 extends comman_methods{
	public void d_login() {
		dr.findElement(By.id("user-name")).sendKeys("problem_user");
		dr.findElement(By.id("password")).sendKeys("secret_sauce");
		dr.findElement(By.id("login-button")).click();
	}

}
