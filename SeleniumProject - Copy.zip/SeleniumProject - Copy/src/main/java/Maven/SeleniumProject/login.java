package Maven.SeleniumProject;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class login extends comman_methods {
	public String url() {
		WebElement wb=dr.findElement(By.xpath("//div[@class='login_logo']"));
		String str=wb.getText();
		return str;
	}
	public XSSFSheet getSheet() throws IOException {
		String sheetname="SauceDemo_Excel.xlsx";
		String sheet="Sheet1";
		FileInputStream fs=new FileInputStream(sheetname);
		XSSFWorkbook sh=new XSSFWorkbook(fs);
		XSSFSheet sq=sh.getSheet(sheet);
		return sq;
	}
	
	
	public String uername() throws IOException {
		XSSFSheet sq=getSheet();
		XSSFRow row1=sq.getRow(1);
		String cell1=row1.getCell(0).getStringCellValue();
		return cell1;
		
	}
	public String password() throws IOException {
		XSSFSheet sq=getSheet();
		XSSFRow row1=sq.getRow(1);
		String cell1=row1.getCell(1).getStringCellValue();
		return cell1;
	}
	public String Sulogin() throws IOException, InterruptedException {
		dr.findElement(By.id("user-name")).sendKeys(uername());
		dr.findElement(By.id("password")).sendKeys(password());
		dr.findElement(By.id("login-button")).click();
		Thread.sleep(1000);
		WebElement wb=dr.findElement(By.className("title"));
		String ao=wb.getText();
		return ao;
	}
	

}
